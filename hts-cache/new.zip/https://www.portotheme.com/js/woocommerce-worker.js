	<!DOCTYPE html>
	<html lang="en-US" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1" />

		<link rel="profile" href="https://gmpg.org/xfn/11" />
		<link rel="pingback" href="https://www.portotheme.com/xmlrpc.php" />
		<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v19.14 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - PortoTheme - Best Wordpress Themes</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - PortoTheme - Best Wordpress Themes" />
	<meta property="og:site_name" content="PortoTheme - Best Wordpress Themes" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.portotheme.com/#website","url":"https://www.portotheme.com/","name":"PortoTheme - Best Wordpress Themes","description":"Best Wordpress Themes, Free Wordpress Themes","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.portotheme.com/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel="alternate" type="application/rss+xml" title="PortoTheme - Best Wordpress Themes &raquo; Feed" href="https://www.portotheme.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="PortoTheme - Best Wordpress Themes &raquo; Comments Feed" href="https://www.portotheme.com/comments/feed/" />
		<link rel="shortcut icon" href="//www.portotheme.com/wp-content/themes/porto/images/logo/favicon.ico" type="image/x-icon" />
				<link rel="apple-touch-icon" href="//www.portotheme.com/wp-content/themes/porto/images/logo/apple-touch-icon.png" />
				<link rel="apple-touch-icon" sizes="120x120" href="//www.portotheme.com/wp-content/themes/porto/images/logo/apple-touch-icon_120x120.png" />
				<link rel="apple-touch-icon" sizes="76x76" href="//www.portotheme.com/wp-content/themes/porto/images/logo/apple-touch-icon_76x76.png" />
				<link rel="apple-touch-icon" sizes="152x152" href="//www.portotheme.com/wp-content/themes/porto/images/logo/apple-touch-icon_152x152.png" />
		<link rel="preload" href="https://www.portotheme.com/wp-content/themes/porto/fonts/porto-font/porto.woff2" as="font" type="font/woff2" crossorigin />		<!-- This site uses the Google Analytics by MonsterInsights plugin v8.12.1 - Using Analytics tracking - https://www.monsterinsights.com/ -->
							<script
				src="//www.googletagmanager.com/gtag/js?id=G-BFLTEZV4HM"  data-cfasync="false" data-wpfc-render="false" async></script>
			<script data-cfasync="false" data-wpfc-render="false">
				var mi_version = '8.12.1';
				var mi_track_user = true;
				var mi_no_track_reason = '';
				
								var disableStrs = [
										'ga-disable-G-BFLTEZV4HM',
														];

				/* Function to detect opted out users */
				function __gtagTrackerIsOptedOut() {
					for (var index = 0; index < disableStrs.length; index++) {
						if (document.cookie.indexOf(disableStrs[index] + '=true') > -1) {
							return true;
						}
					}

					return false;
				}

				/* Disable tracking if the opt-out cookie exists. */
				if (__gtagTrackerIsOptedOut()) {
					for (var index = 0; index < disableStrs.length; index++) {
						window[disableStrs[index]] = true;
					}
				}

				/* Opt-out function */
				function __gtagTrackerOptout() {
					for (var index = 0; index < disableStrs.length; index++) {
						document.cookie = disableStrs[index] + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
						window[disableStrs[index]] = true;
					}
				}

				if ('undefined' === typeof gaOptout) {
					function gaOptout() {
						__gtagTrackerOptout();
					}
				}
								window.dataLayer = window.dataLayer || [];

				window.MonsterInsightsDualTracker = {
					helpers: {},
					trackers: {},
				};
				if (mi_track_user) {
					function __gtagDataLayer() {
						dataLayer.push(arguments);
					}

					function __gtagTracker(type, name, parameters) {
						if (!parameters) {
							parameters = {};
						}

						if (parameters.send_to) {
							__gtagDataLayer.apply(null, arguments);
							return;
						}

						if (type === 'event') {
														parameters.send_to = monsterinsights_frontend.v4_id;
							var hookName = name;
							if (typeof parameters['event_category'] !== 'undefined') {
								hookName = parameters['event_category'] + ':' + name;
							}

							if (typeof MonsterInsightsDualTracker.trackers[hookName] !== 'undefined') {
								MonsterInsightsDualTracker.trackers[hookName](parameters);
							} else {
								__gtagDataLayer('event', name, parameters);
							}
							
													} else {
							__gtagDataLayer.apply(null, arguments);
						}
					}

					__gtagTracker('js', new Date());
					__gtagTracker('set', {
						'developer_id.dZGIzZG': true,
											});
										__gtagTracker('config', 'G-BFLTEZV4HM', {"forceSSL":"true","link_attribution":"true","page_path":'\/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer} );
															window.gtag = __gtagTracker;										(function () {
						/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
						/* ga and __gaTracker compatibility shim. */
						var noopfn = function () {
							return null;
						};
						var newtracker = function () {
							return new Tracker();
						};
						var Tracker = function () {
							return null;
						};
						var p = Tracker.prototype;
						p.get = noopfn;
						p.set = noopfn;
						p.send = function () {
							var args = Array.prototype.slice.call(arguments);
							args.unshift('send');
							__gaTracker.apply(null, args);
						};
						var __gaTracker = function () {
							var len = arguments.length;
							if (len === 0) {
								return;
							}
							var f = arguments[len - 1];
							if (typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function') {
								if ('send' === arguments[0]) {
									var hitConverted, hitObject = false, action;
									if ('event' === arguments[1]) {
										if ('undefined' !== typeof arguments[3]) {
											hitObject = {
												'eventAction': arguments[3],
												'eventCategory': arguments[2],
												'eventLabel': arguments[4],
												'value': arguments[5] ? arguments[5] : 1,
											}
										}
									}
									if ('pageview' === arguments[1]) {
										if ('undefined' !== typeof arguments[2]) {
											hitObject = {
												'eventAction': 'page_view',
												'page_path': arguments[2],
											}
										}
									}
									if (typeof arguments[2] === 'object') {
										hitObject = arguments[2];
									}
									if (typeof arguments[5] === 'object') {
										Object.assign(hitObject, arguments[5]);
									}
									if ('undefined' !== typeof arguments[1].hitType) {
										hitObject = arguments[1];
										if ('pageview' === hitObject.hitType) {
											hitObject.eventAction = 'page_view';
										}
									}
									if (hitObject) {
										action = 'timing' === arguments[1].hitType ? 'timing_complete' : hitObject.eventAction;
										hitConverted = mapArgs(hitObject);
										__gtagTracker('event', action, hitConverted);
									}
								}
								return;
							}

							function mapArgs(args) {
								var arg, hit = {};
								var gaMap = {
									'eventCategory': 'event_category',
									'eventAction': 'event_action',
									'eventLabel': 'event_label',
									'eventValue': 'event_value',
									'nonInteraction': 'non_interaction',
									'timingCategory': 'event_category',
									'timingVar': 'name',
									'timingValue': 'value',
									'timingLabel': 'event_label',
									'page': 'page_path',
									'location': 'page_location',
									'title': 'page_title',
								};
								for (arg in args) {
																		if (!(!args.hasOwnProperty(arg) || !gaMap.hasOwnProperty(arg))) {
										hit[gaMap[arg]] = args[arg];
									} else {
										hit[arg] = args[arg];
									}
								}
								return hit;
							}

							try {
								f.hitCallback();
							} catch (ex) {
							}
						};
						__gaTracker.create = newtracker;
						__gaTracker.getByName = newtracker;
						__gaTracker.getAll = function () {
							return [];
						};
						__gaTracker.remove = noopfn;
						__gaTracker.loaded = true;
						window['__gaTracker'] = __gaTracker;
					})();
									} else {
										console.log("");
					(function () {
						function __gtagTracker() {
							return null;
						}

						window['__gtagTracker'] = __gtagTracker;
						window['gtag'] = __gtagTracker;
					})();
									}
			</script>
				<!-- / Google Analytics by MonsterInsights -->
		<style id='restrict-content-pro-content-upgrade-redirect-style-inline-css'>
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-25 {
  width: calc(25% - 0.5rem);
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-25 .wp-block-button__link {
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-50 {
  width: calc(50% - 0.5rem);
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-50 .wp-block-button__link {
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-75 {
  width: calc(75% - 0.5rem);
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-75 .wp-block-button__link {
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-100 {
  margin-right: 0;
  width: 100%;
}
.wp-block-restrict-content-pro-content-upgrade-redirect .wp-block-button__width-100 .wp-block-button__link {
  width: 100%;
}

/*# sourceMappingURL=style-content-upgrade-redirect.css.map*/
</style>
<link rel='stylesheet' id='classic-theme-styles-css' href='https://www.portotheme.com/wp-includes/css/classic-themes.min.css?ver=1' media='all' />
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--primary: #0088cc;--wp--preset--color--secondary: #e36159;--wp--preset--color--tertiary: #2baab1;--wp--preset--color--quaternary: #383f48;--wp--preset--color--dark: #212529;--wp--preset--color--light: #ffffff;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='bbp-default-css' href='https://www.portotheme.com/wp-content/plugins/bbpress/templates/default/css/bbpress.min.css?ver=2.6.9' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://www.portotheme.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.7.2' media='all' />
<link rel='stylesheet' id='gdatt-attachments-css' href='https://www.portotheme.com/wp-content/plugins/gd-bbpress-attachments/css/front.min.css?ver=4.5_b2500_free' media='all' />
<link rel='stylesheet' id='sib-front-css-css' href='https://www.portotheme.com/wp-content/plugins/mailin/css/mailin-front.css?ver=6.1.1' media='all' />
<link rel='stylesheet' id='porto-css-vars-css' href='https://www.portotheme.com/wp-content/uploads/porto_styles/theme_css_vars.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='js_composer_front-css' href='https://www.portotheme.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.10.0' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://www.portotheme.com/wp-content/uploads/porto_styles/bootstrap.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-plugins-css' href='https://www.portotheme.com/wp-content/themes/porto/css/plugins.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-theme-css' href='https://www.portotheme.com/wp-content/themes/porto/css/theme.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-shortcodes-css' href='https://www.portotheme.com/wp-content/uploads/porto_styles/shortcodes.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-theme-bbpress-css' href='https://www.portotheme.com/wp-content/themes/porto/css/theme_bbpress.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-theme-wpb-css' href='https://www.portotheme.com/wp-content/themes/porto/css/theme_wpb.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-dynamic-style-css' href='https://www.portotheme.com/wp-content/uploads/porto_styles/dynamic_style.css?ver=6.7.2' media='all' />
<link rel='stylesheet' id='porto-style-css' href='https://www.portotheme.com/wp-content/themes/porto/style.css?ver=6.7.2' media='all' />
<style id='porto-style-inline-css'>
.side-header-narrow-bar-logo{max-width:180px}@media (min-width:992px){}#header .header-main .header-left,#header .header-main .header-center,#header .header-main .header-right,.fixed-header #header .header-main .header-left,.fixed-header #header .header-main .header-right,.fixed-header #header .header-main .header-center,.header-builder-p .header-main{padding-top:30px;padding-bottom:30px}@media (max-width:991px){#header .header-main .header-left,#header .header-main .header-center,#header .header-main .header-right,.fixed-header #header .header-main .header-left,.fixed-header #header .header-main .header-right,.fixed-header #header .header-main .header-center,.header-builder-p .header-main{padding-top:20px;padding-bottom:20px}}.page-top .sort-source{position:static;text-align:center;margin-top:5px;border-width:0}.page-top ul.breadcrumb{-ms-flex-pack:center;justify-content:center}.page-top .page-title{font-weight:700}#header .mobile-toggle{font-size:0.8rem;background-color:#ffffff;color:#222529}.porto-block-html-top{position:sticky;top:0;left:0;width:100%;z-index:1099;overflow:hidden;box-shadow:0 3px 3px rgba(31,34,37,.5)}.porto-block-html-top .mfp-close{top:50%;transform:translateY(-50%) rotateZ(45deg);color:inherit;opacity:.7}.porto-block-html-top a{color:#fff}body{overflow:hidden}.mobile-menu li:active a,.mobile-menu li:hover a{color:#fff !important}.btn-modern{font-weight:700}.vc_btn3.vc_btn3-icon-right .vc_btn3-icon{margin-left:10px;font-size:1.4em}.home-intro p{font-size:1.15em}.home-intro p em{font-size:1.2727em;padding-bottom:10px;background:url(/wp-content/uploads/images/theme_path.png) no-repeat right bottom;background-size:contain}.porto-u-sub-heading{letter-spacing:-0.03em}div.stats-desc > div.counter_suffix{vertical-align:top;margin-left:10px}.porto-sicon-header + .porto-sicon-description{margin-top:8px}.porto-sicon-box a i{font-size:1.5em;margin-left:8px;position:relative;top:1px}.our-clients .owl-carousel .owl-stage{display:-ms-flexbox;display:flex;margin-bottom:50px}.our-clients .wpb_text_column{background:#fff;padding:30px 25px;border-radius:4px;margin-bottom:0;height:100%}.our-clients .center .wpb_text_column{background:#08c}.our-clients .center .star-ratinpg span:before,.our-clients .center .text-dark,.our-clients .center p{color:#fff !important}.our-clients .star-rating{margin-bottom:8px}.our-clients .star-rating span:before{color:#08c}.our-clients p{font-size:.9286em}.page-top .breadcrumbs-wrap{opacity:.7;font-size:1em;font-weight:700;margin-bottom:10px}.page-top .page-title{font-size:2.57em;font-weight:800}.portfolio-item .thumb-info{background:#fff;border-radius:3px;padding:8px;position:relative;border:1px solid #efefef;box-shadow:0 0 40px 0 rgb(0 0 0 / 4%)}.portfolio-item.outimage{text-align:left}.portfolio-item .portfolio-brief-content{padding-left:0 !important;padding-right:0 !important;margin-top:0 !important}.portfolio-item .portfolio-title{font-size:17px;letter-spacing:-0.05em;margin-bottom:0.75rem}.portfolio-item .color-body{font-size:18px;font-weight:700;order:1;margin-top:0.625rem;color:#222529;letter-spacing:-0.03em}.portfolio-item .action,.portfolio-item .clearfix{display:none}.portfolio-item{display:flex;flex-direction:column}.single-portfolio .related-portfolios{margin-top:0 !important}#footer .footer-bottom{padding-top:5px}#footer .footer-main>.container{padding:2.4rem 0 0}#footer .follow-us{text-align:center;margin-bottom:0}#footer .follow-us .share-links a{box-shadow:none}#bbpress-forums ul.bbp-forums,#bbpress-forums ul.bbp-lead-topic,#bbpress-forums ul.bbp-replies,#bbpress-forums ul.bbp-search-results,#bbpress-forums ul.bbp-topics,#bbpress-forums div.bbp-forum-content,#bbpress-forums div.bbp-reply-content,#bbpress-forums div.bbp-topic-content{font-size:14px;line-height:24px}.bbpress-wrapper .bbp-search-form{display:none}#bbpress-forums ul.bbp-forums,#bbpress-forums ul.bbp-lead-topic,#bbpress-forums ul.bbp-replies,#bbpress-forums ul.bbp-search-results,#bbpress-forums ul.bbp-topics{border-width:0 !important}#bbpress-forums li.bbp-footer,#bbpress-forums li.bbp-header{background:none;border-width:0;padding:0}.forum-titles > li{font-size:14px !important;font-weight:600;text-transform:uppercase;color:#777 !important;line-height:1;letter-spacing:.15em;margin-bottom:15px !important}.bbp-forum-title{font-size:20px;font-weight:600;line-height:1;letter-spacing:-.05em}#bbpress-forums .bbp-forum-info .bbp-forum-content,#bbpress-forums p.bbp-topic-meta{margin-top:3px;font-size:15px;font-weight:500;line-height:24px;letter-spacing:-.025em}#bbpress-forums div.odd,#bbpress-forums ul.odd{background:#fff}#bbpress-forums li.bbp-body ul.forum:first-child,#bbpress-forums li.bbp-body ul.topic:first-child{border-top-width:0}#bbpress-forums li.bbp-body ul.forum,#bbpress-forums li.bbp-body ul.topic{padding:19px 0}li.bbp-forum-freshness,li.bbp-topic-freshness{text-align:left}.bbp-forum-freshness,.bbp-topic-freshness{display:flex;flex-direction:column}.bbp-forum-freshness > a,.bbp-topic-freshness > a{font-size:13px;font-weight:600;letter-spacing:-.05em;line-height:13px;order:1;color:#777}li.bbp-forum-reply-count,li.bbp-forum-topic-count,li.bbp-topic-reply-count,li.bbp-topic-voice-count,li.bbp-forum-freshness,li.bbp-topic-freshness{font-size:16px;font-weight:600;color:#222529}#bbpress-forums p.bbp-topic-meta{font-size:16px;text-transform:capitalize;font-weight:600;letter-spacing:-.05em}#bbpress-forums .bbp-topic-meta .bbp-author-name{color:#222529}li.bbp-forum-info,li.bbp-topic-title{width:45%}li.bbp-forum-reply-count,li.bbp-forum-topic-count,li.bbp-topic-reply-count,li.bbp-topic-voice-count{width:20%}li.bbp-forum-freshness,li.bbp-topic-freshness{width:15%}.porto-porto-custom-sidebar-forumsidebar h3.widget-title,.widget_display_topics h3.widget-title,.widget_display_replies h3.widget-title{font-size:18px;color:#777;letter-spacing:.1em;font-weight:600}.bbp-topics-widget li,.bbp-replies-widget li{display:flex;flex-direction:column;position:relative;padding-top:17px !important;padding-bottom:17px !important;font-size:0;font-weight:600;line-height:1}.bbp-topics-widget .bbp-author-avatar,.bbp-replies-widget .bbp-author-avatar{position:absolute;top:20px}.bbp-topics-widget .bbp-forum-title,.bbp-replies-widget .bbp-reply-topic-title{padding-left:65px;line-height:24px}.bbp-topics-widget a,.bbp-replies-widget a{font-size:18px;letter-spacing:-.025em}.bbp-topics-widget .bbp-author-name,.bbp-replies-widget .bbp-author-name{padding-left:65px;text-transform:capitalize;font-size:16px;letter-spacing:-.05em;color:#222529}.bbp-topics-widget li>div:last-child,.bbp-replies-widget li>time:last-child{font-size:13px;padding-left:65px}.bbp-topics-widget .topic-author,.bbp-replies-widget .topic-author{margin-top:2px;margin-bottom:5px}.bbp-replies-widget img{margin-right:8px}.bbp-topics-widget,.bbp-replies-widget{border-bottom:none !important}.bbp-topics-widget li,.bbp-replies-widget li{border-top-width:0 !important}.custom-forum-link1{font-size:16px !important;letter-spacing:-.025em;font-weight:600}.custom-page-header #bbp-search-form{max-width:850px;position:relative}.custom-page-header #bbp_search{width:100%;height:55px;border-radius:4px}.custom-page-header #bbp_search_submit{position:absolute;right:5px;top:5px;bottom:5px;width:140px;border-radius:4px}.custom-page-header .top-keyword a{display:inline-block;margin:3px 3px;padding:7px 14px;color:#fff;background-color:#121314;font-size:13px;font-weight:600;letter-spacing:-.025em;border-radius:4px;line-height:1;white-space:nowrap}.custom-forum-block .vc_column-inner{background-color:#f7f7f7;border-radius:4px;padding:20px !important}.custom-forum-count{position:absolute;right:34px;top:27px;font-size:40px;font-weight:700;color:#ccc;letter-spacing:-.05em}.bbp-topic-permalink{font-size:20px;font-weight:600;line-height:1;letter-spacing:-.05em}div.bbp-template-notice li,div.bbp-template-notice p{font-size:13px}#bbpress-forums .bbp-pagination-links a,#bbpress-forums .bbp-pagination-links span.current{width:46px;height:46px;line-height:46px;border-radius:50%}.bbp-pagination-links .next:before{content:"\f105"}.bbp-pagination-links .prev:before{content:"\f104"}#bbpress-forums .bbp-pagination a:focus,#bbpress-forums .bbp-pagination a:hover,#bbpress-forums .bbp-pagination span.current,#bbpress-forums .bbp-topic-pagination a:focus,#bbpress-forums .bbp-topic-pagination a:hover,#bbpress-forums .bbp-topic-pagination span.current{color:#fff}.bbp-topic-form legend,.bbp-reply-form legend{font-weight:600;color:#222529}.bbp-pagination{margin-bottom:40px}#bbpress-forums .bbp-topic-pagination a{border-radius:50%;width:20px;height:20px;display:inline-block;line-height:20px;padding:0}#subscription-toggle,#favorite-toggle{font-size:14px;font-weight:600;margin-bottom:15px}.bbp-author-avatar img{border-radius:50%;max-width:55px}#bbpress-forums .widget_display_replies img.avatar,#bbpress-forums .widget_display_topics img.avatar,#bbpress-forums div.bbp-template-notice img.avatar,#bbpress-forums p.bbp-topic-meta img.avatar,#bbpress-forums ul.bbp-reply-revision-log img.avatar,#bbpress-forums ul.bbp-topic-revision-log img.avatar{max-height:24px;max-width:24px}.bbp-pagination-count{line-height:50px;font-size:14px}div.bbp-template-notice,div.indicator-hint{margin-bottom:30px}.bbp-topic-started-by .bbp-author-link{margin-left:10px}#bbpress-forums fieldset.bbp-form label{margin-bottom:6px;font-size:14px;vertical-align:middle}#bbpress-forums fieldset.bbp-form input,#bbpress-forums fieldset.bbp-form p,#bbpress-forums fieldset.bbp-form select,#bbpress-forums fieldset.bbp-form textarea{margin-bottom:.5rem;border-radius:4px}#bbpress-forums div.wp-editor-container{border-radius:4px}#bbpress-forums fieldset.bbp-form input[type=password],#bbpress-forums fieldset.bbp-form input[type=text],#bbpress-forums fieldset.bbp-form select{min-height:40px;height:40px;padding:5px 15px}.bbp-submit-wrapper button{font-size:14px;font-weight:600;border-radius:4px;padding-left:40px;padding-right:40px}input#bbp_topic_title{width:100%}#bbpress-forums li.bbp-header .bbp-reply-author,#bbpress-forums li.bbp-header .bbp-reply-content{font-size:14px !important;font-weight:600;text-transform:uppercase;color:#777 !important;line-height:1;letter-spacing:.15em;margin-bottom:10px !important}#bbpress-forums div.bbp-reply-author .bbp-author-name,#bbpress-forums div.bbp-topic-author .bbp-author-name{font-size:16px;font-weight:600;text-transform:capitalize}.forums.bbp-replies .bbp-footer{display:none}div.bbp-forum-header,div.bbp-reply-header,div.bbp-topic-header{border-top-width:0}div.bbp-forum-header,div.bbp-reply-header,div.bbp-topic-header,li.bbp-body div.hentry{padding:14px}span.bbp-admin-links a{font-size:inherit}.bbp-reply-header{font-size:14px}#bbpress-forums div.reply{padding:14px}#bbpress-forums li.bbp-header .bbp-search-author,#bbpress-forums li.bbp-header .bbp-search-content{font-size:14px !important;font-weight:600;text-transform:uppercase;color:#777 !important;line-height:1;letter-spacing:.15em;margin-bottom:20px !important}.bbp-search-results .bbp-topic-permalink{font-size:14px;margin-left:10px}.bbp-search-results .bbp-footer{display:none}.bbp-search-results .bbp-topic-title h3 a{margin-left:10px}.post-type-archive-forum .page-top{display:none}.bbpress #main{background:#fff}.bbp-forum-content ul.sticky,.bbp-topics ul.sticky,.bbp-topics ul.super-sticky,.bbp-topics-front ul.super-sticky{background:#fff !important}#bbpress-forums #bbp-user-wrapper fieldset.bbp-form,#bbpress-forums #bbp-user-wrapper ul.bbp-forums,#bbpress-forums #bbp-user-wrapper ul.bbp-lead-topic,#bbpress-forums #bbp-user-wrapper ul.bbp-replies,#bbpress-forums #bbp-user-wrapper ul.bbp-topics{clear:both}.bbp-reply-content code{white-space:pre-wrap;word-wrap:break-word}form [for="porto_private_area"]{font-size:16px !important;line-height:20px;color:#08c;font-weight:600}form .porto_forum_private_area{width:100%}#bbp-your-profile .bbp-form{clear:none !important}#bbp-your-profile .form-table,#bbp-your-profile .form-table label{font-size:14px}#bbp-your-profile .form-table th{width:200px}#bbp-your-profile .form-table #rpi_label1{width:100%}.ptheme-support-status{display:inline-block;font-size:18px !important;font-weight:700 !important;color:#f4511e !important}#porto-purchase-extend{margin:0 16px;font-size:16px;background-color:#08c;color:#fff;padding:8px;border-radius:4px}.porto-support-role{font-size:13px;background:#333;color:#fff;border-radius:4px;font-weight:500;text-transform:uppercase}.porto-support-role.purchased{background:#82b541}#bbpress-forums #bbp-user-wrapper h2:not(.entry-title){font-size:1.4em;margin:0;padding-bottom:10px;padding-top:0;clear:none}form .rpi-profile-item1{font-size:15px;color:#08c}.porto-private-content{background-color:#FCF8E3;color:#C09853;padding:20px;border-radius:8px;font-size:16px;font-weight:600}.porto-private-content p:last-child{margin-bottom:0 !important}.bbp-reply-content .bbp-attachments{background:#d9e5f1;border:none;border-radius:8px;padding:35px 25px 25px}.bbp-reply-content .bbp-attachments li{margin-right:10px!important;margin-bottom:0 !important}.bbp-reply-content .bbp-attachments .wp-caption-text{font-style:normal;text-align:center;font-size:13px}.bbp-reply-content .bbp-attachments .wp-caption-text a{font-weight:500;font-size:13px;line-height:19px;color:#333333}#bbpress-forums div.bbp-forum-author .bbp-author-role,#bbpress-forums div.bbp-reply-author .bbp-author-role,#bbpress-forums div.bbp-topic-author .bbp-author-role{font-size:15px;line-height:30px;color:#f4511e;font-style:normal;font-weight:600}.porto-porto-custom-sidebar-forumsidebar .wpb_content_element #bbp_search{padding:9px 12px !important}.porto-porto-custom-sidebar-forumsidebar .wpb_content_element{margin-bottom:0 !important}#bbpress-forums p.bbp-topic-meta span{white-space:wrap !important}#bbpress-forums .type-topic.sticky{background-color:#f4f4f4 !important;padding:30px 19px 25px !important}
</style>
<link rel='stylesheet' id='styles-child-css' href='https://www.portotheme.com/wp-content/themes/porto-child/style.css?ver=6.1.1' media='all' />
<script type="text/javascript">
            window._nslDOMReady = function (callback) {
                if ( document.readyState === "complete" || document.readyState === "interactive" ) {
                    callback();
                } else {
                    document.addEventListener( "DOMContentLoaded", callback );
                }
            };
            </script><script src='https://www.portotheme.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.min.js?ver=8.12.1' id='monsterinsights-frontend-script-js'></script>
<script data-cfasync="false" data-wpfc-render="false" id='monsterinsights-frontend-script-js-extra'>var monsterinsights_frontend = {"js_events_tracking":"true","download_extensions":"doc,pdf,ppt,zip,xls,docx,pptx,xlsx","inbound_paths":"[{\"path\":\"\\\/go\\\/\",\"label\":\"affiliate\"},{\"path\":\"\\\/recommend\\\/\",\"label\":\"affiliate\"}]","home_url":"https:\/\/www.portotheme.com","hash_tracking":"false","ua":"","v4_id":"G-BFLTEZV4HM"};</script>
<script src='https://www.portotheme.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.1' id='jquery-core-js'></script>
<script src='https://www.portotheme.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script id='sib-front-js-js-extra'>
var sibErrMsg = {"invalidMail":"Please fill out valid email address","requiredField":"Please fill out required fields","invalidDateFormat":"Please fill out valid date format","invalidSMSFormat":"Please fill out valid phone number"};
var ajax_sib_front_object = {"ajax_url":"https:\/\/www.portotheme.com\/wp-admin\/admin-ajax.php","ajax_nonce":"62eeaf19c8","flag_url":"https:\/\/www.portotheme.com\/wp-content\/plugins\/mailin\/img\/flags\/"};
</script>
<script src='https://www.portotheme.com/wp-content/plugins/mailin/js/mailin-front.js?ver=1676442233' id='sib-front-js-js'></script>
<link rel="https://api.w.org/" href="https://www.portotheme.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.portotheme.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.portotheme.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.1.1" />
        <!-- PushAlert WordPress 2.5.4 -->
        <script type="text/javascript">
        var pushalert_sw_file = 'https://www.portotheme.com/?pa_service_worker=1';
var pushalert_manifest_file = 'https://www.portotheme.com/wp-content/plugins/pushalert-web-push-notifications/manifest.json';

            (function (d, t) {
                var g = d.createElement(t),
                        s = d.getElementsByTagName(t)[0];
                g.src = "//cdn.pushalert.co/integrate_588864e0645eef241606a11076d1e610.js";
                s.parentNode.insertBefore(g, s);
            }(document, "script"));
        </script>
        <!-- End PushAlert WordPress -->
        		<script type="text/javascript">
		WebFontConfig = {
			google: { families: [ 'Poppins:400,500,600,700,800','Open+Sans:400,600,700&display=swap' ] }
		};
		(function(d) {
			var wf = d.createElement('script'), s = d.scripts[d.scripts.length - 1];
			wf.src = 'https://www.portotheme.com/wp-content/themes/porto/js/libs/webfont.js';
			wf.async = true;
			s.parentNode.insertBefore(wf, s);
		})(document);</script>
		<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<style type="text/css">div.nsl-container[data-align="left"] {
    text-align: left;
}

div.nsl-container[data-align="center"] {
    text-align: center;
}

div.nsl-container[data-align="right"] {
    text-align: right;
}


div.nsl-container div.nsl-container-buttons a[data-plugin="nsl"] {
    text-decoration: none;
    box-shadow: none;
    border: 0;
}

div.nsl-container .nsl-container-buttons {
    display: flex;
    padding: 5px 0;
}

div.nsl-container.nsl-container-block .nsl-container-buttons {
    display: inline-grid;
    grid-template-columns: minmax(145px, auto);
}

div.nsl-container-block-fullwidth .nsl-container-buttons {
    flex-flow: column;
    align-items: center;
}

div.nsl-container-block-fullwidth .nsl-container-buttons a,
div.nsl-container-block .nsl-container-buttons a {
    flex: 1 1 auto;
    display: block;
    margin: 5px 0;
    width: 100%;
}

div.nsl-container-inline {
    margin: -5px;
    text-align: left;
}

div.nsl-container-inline .nsl-container-buttons {
    justify-content: center;
    flex-wrap: wrap;
}

div.nsl-container-inline .nsl-container-buttons a {
    margin: 5px;
    display: inline-block;
}

div.nsl-container-grid .nsl-container-buttons {
    flex-flow: row;
    align-items: center;
    flex-wrap: wrap;
}

div.nsl-container-grid .nsl-container-buttons a {
    flex: 1 1 auto;
    display: block;
    margin: 5px;
    max-width: 280px;
    width: 100%;
}

@media only screen and (min-width: 650px) {
    div.nsl-container-grid .nsl-container-buttons a {
        width: auto;
    }
}

div.nsl-container .nsl-button {
    cursor: pointer;
    vertical-align: top;
    border-radius: 4px;
}

div.nsl-container .nsl-button-default {
    color: #fff;
    display: flex;
}

div.nsl-container .nsl-button-icon {
    display: inline-block;
}

div.nsl-container .nsl-button-svg-container {
    flex: 0 0 auto;
    padding: 8px;
    display: flex;
    align-items: center;
}

div.nsl-container svg {
    height: 24px;
    width: 24px;
    vertical-align: top;
}

div.nsl-container .nsl-button-default div.nsl-button-label-container {
    margin: 0 24px 0 12px;
    padding: 10px 0;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 16px;
    line-height: 20px;
    letter-spacing: .25px;
    overflow: hidden;
    text-align: center;
    text-overflow: clip;
    white-space: nowrap;
    flex: 1 1 auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-transform: none;
    display: inline-block;
}

div.nsl-container .nsl-button-google[data-skin="dark"] .nsl-button-svg-container {
    margin: 1px;
    padding: 7px;
    border-radius: 3px;
    background: #fff;
}

div.nsl-container .nsl-button-google[data-skin="light"] {
    border-radius: 1px;
    box-shadow: 0 1px 5px 0 rgba(0, 0, 0, .25);
    color: RGBA(0, 0, 0, 0.54);
}

div.nsl-container .nsl-button-apple .nsl-button-svg-container {
    padding: 0 6px;
}

div.nsl-container .nsl-button-apple .nsl-button-svg-container svg {
    height: 40px;
    width: auto;
}

div.nsl-container .nsl-button-apple[data-skin="light"] {
    color: #000;
    box-shadow: 0 0 0 1px #000;
}

div.nsl-container .nsl-button-facebook[data-skin="white"] {
    color: #000;
    box-shadow: inset 0 0 0 1px #000;
}

div.nsl-container .nsl-button-facebook[data-skin="light"] {
    color: #1877F2;
    box-shadow: inset 0 0 0 1px #1877F2;
}

div.nsl-container .nsl-button-apple div.nsl-button-label-container {
    font-size: 17px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
}

div.nsl-container .nsl-button-slack div.nsl-button-label-container {
    font-size: 17px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
}

div.nsl-container .nsl-button-slack[data-skin="light"] {
    color: #000000;
    box-shadow: inset 0 0 0 1px #DDDDDD;
}

div.nsl-container .nsl-button-tiktok[data-skin="light"] {
    color: #161823;
    box-shadow: 0 0 0 1px rgba(22, 24, 35, 0.12);
}

.nsl-clear {
    clear: both;
}

.nsl-container {
    clear: both;
}

/*Button align start*/

div.nsl-container-inline[data-align="left"] .nsl-container-buttons {
    justify-content: flex-start;
}

div.nsl-container-inline[data-align="center"] .nsl-container-buttons {
    justify-content: center;
}

div.nsl-container-inline[data-align="right"] .nsl-container-buttons {
    justify-content: flex-end;
}


div.nsl-container-grid[data-align="left"] .nsl-container-buttons {
    justify-content: flex-start;
}

div.nsl-container-grid[data-align="center"] .nsl-container-buttons {
    justify-content: center;
}

div.nsl-container-grid[data-align="right"] .nsl-container-buttons {
    justify-content: flex-end;
}

div.nsl-container-grid[data-align="space-around"] .nsl-container-buttons {
    justify-content: space-around;
}

div.nsl-container-grid[data-align="space-between"] .nsl-container-buttons {
    justify-content: space-between;
}

/* Button align end*/

/* Redirect */

#nsl-redirect-overlay {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: fixed;
    z-index: 1000000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    backdrop-filter: blur(1px);
    background-color: RGBA(0, 0, 0, .32);;
}

#nsl-redirect-overlay-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: white;
    padding: 30px;
    border-radius: 10px;
}

#nsl-redirect-overlay-spinner {
    content: '';
    display: block;
    margin: 20px;
    border: 9px solid RGBA(0, 0, 0, .6);
    border-top: 9px solid #fff;
    border-radius: 50%;
    box-shadow: inset 0 0 0 1px RGBA(0, 0, 0, .6), 0 0 0 1px RGBA(0, 0, 0, .6);
    width: 40px;
    height: 40px;
    animation: nsl-loader-spin 2s linear infinite;
}

@keyframes nsl-loader-spin {
    0% {
        transform: rotate(0deg)
    }
    to {
        transform: rotate(360deg)
    }
}

#nsl-redirect-overlay-title {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    font-size: 18px;
    font-weight: bold;
    color: #3C434A;
}

#nsl-redirect-overlay-text {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    text-align: center;
    font-size: 14px;
    color: #3C434A;
}

/* Redirect END*/</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>	</head>
	<body class="error404 wp-embed-responsive full blog-1 wpb-js-composer js-comp-ver-6.10.0 vc_responsive">
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0.49803921568627" /><feFuncG type="table" tableValues="0 0.49803921568627" /><feFuncB type="table" tableValues="0 0.49803921568627" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 0.27843137254902" /><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0 0" /><feFuncG type="table" tableValues="0 0.64705882352941" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.78039215686275 1" /><feFuncG type="table" tableValues="0 0.94901960784314" /><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.44705882352941 0.4" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;" ><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB" ><feFuncR type="table" tableValues="0.098039215686275 1" /><feFuncG type="table" tableValues="0 0.66274509803922" /><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg>
	<div class="page-wrapper"><!-- page wrapper -->
		<div class="porto-html-block porto-block-html-top"><div class="background-color-dark text-center text-color-light position-relative py-2"><div class="container">Check out New Creative & WooCommerce WordPress Theme <a href="https://alpustheme.com/alpus/" target="_blank"><b>Alpus Pro</b></a>, comes with 60+ niche prebuilt webistes. <a href="https://alpustheme.com/alpus/" target="_blank" class="btn btn-modern btn-light btn-borders btn-rounded btn-sm ml-2">Check Alpus Pro</a></div><button class="mfp-close"></button></div></div>
											<!-- header wrapper -->
				<div class="header-wrapper wide fixed-header header-transparent-bottom-border">
										
<header id="header" class="header-builder header-builder-p">
<div class="porto-block" data-id="484"><div class="container-fluid"><style>.vc_custom_1674324260361{margin-right: 6px !important;}#header .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234.main-menu > li.menu-item > a, .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234 .sidebar-menu > li.menu-item > a, #header .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234.porto-popup-menu .main-menu > li.menu-item > a{color: #ffffff;}#header .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234.main-menu > li.menu-item.active:hover > a, #header .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234.main-menu > li.menu-item:hover > a, .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234 .sidebar-menu > li.menu-item:hover > a, .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234 .sidebar-menu > li.menu-item.active > a, #header .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234.porto-popup-menu .main-menu > li.menu-item.active:hover > a, #header .wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234.porto-popup-menu .main-menu > li.menu-item:hover > a{color: #ffffff;}.wpb_custom_e325e190e075e76e8632d8c652b58be2.mobile-toggle{padding: 14px 18px 14px 18px !important;}#header .container-fluid { padding-left: 10px; padding-right: 10px; }
#header .container-fluid > .row { align-items: center; }
#header .secondary-menu > li.menu-item > a { font-size: .875rem; letter-spacing: -.02em; padding: .5rem 1rem; }

#header .main-menu > li.menu-item > a { color: #fff !important; }

@media (min-width: 1828px) {
	#header .container-fluid {
	    max-width: 1828px;
	}
	.pe-xxl-5 {
		margin-right: 3rem;
	}
}
#header .container-fluid {
    padding-left: 10px;
    padding-right: 10px;
}

@media (min-width: 1600px) {
	#header .main-menu:not(.secondary-menu)>li.menu-item { 
		margin-right: 27px; 
	}
}
@media (max-width: 1827px) and (min-width: 480px){
	#header .container-fluid {
	    padding-left: 3.125%;
	    padding-right: 3.125%;
	}
}
@media (min-width: 1460px) {
	.me-cxl-space {
		margin-right: 3.1875rem  !important;
	}
	.pe-cxl-5 {
		padding-right: 3rem !important;
	}
}
@media (max-width: 1459px) {
	#menu-secondary-menu {
		display: none;
	}
}

#header .main-menu .mega-item > ul { display: flex; flex-wrap: wrap; min-width: 485px; padding: 22px 8px; }
#header .mega-item > ul > li { width: 50%; border-bottom: 0; }
#header .mega-item > ul > li:not(:last-child) { border-bottom: 0; }
.mega-item li > a { font-size: 14px!important; font-weight: 500!important; padding: 8px 22px!important; }
.mega-item li > a.nolink { font-weight: 700!important; background: none!important; }
#footer .footer-social { margin-left: 4px; }
.link-boxes > * { border-top: 1px solid; border-right: 1px solid; border-color: rgba(255, 255, 255, .2); padding: 1.8rem 0 .05rem; margin-bottom: 0; transition: background-color .2s; cursor: pointer; }
.link-boxes > *:hover { background-color: #1d2024; border-color: transparent; border-right: 1px solid rgba(255,255,255,0.1); }
#header .mobile-nav-wrap { background: #fff; }
#header .vc_column_container, .mega-menu li.pos-fullwidth, .sidebar-menu li.menu-item { position: static; }
#header .main-menu .popup { left: 0 !important }
.page-top .page-sub-title { font-size: 22px; line-height: 1.6; letter-spacing: -.05em; }
#header .main-menu .top-item a { font-weight: 700; }
#header .text-custom-color > a { color: inherit !important; }
#header .main-menu .top-item:hover > a { background: none !important; }
#header .main-menu .top-item .thumb-info { opacity: 1; top: 0; left: 71%; }
#header .main-menu .top-item.shop-item .thumb-info { top: -5px; left: 64%; }
#header .main-menu .top-item .thumb-info-wrapper { box-shadow: none; }
#header .main-menu .top-item .thumb-info-image { width: 85px; height: 33px; }
#header .main-menu .top-item.shop-item .thumb-info-image { width: 105px; height: 36px; }
#header .pos-fullwidth ul li { border-bottom: none !important; }
#header .pos-fullwidth li > a { font-size: 15px !important; padding: 9px 22px 8px; }
#header .pos-fullwidth li > a:hover { background: #f4f4f4 !important; text-decoration: none !important; }
#header .pos-fullwidth .inner { padding: 22px 0 30px }
#header .pos-fullwidth li:not(:last-child) ul { border-right: 1px solid #e7e7e7; padding: 0 20px 0 10px; }
#header .pos-fullwidth li:last-child ul { padding-left: 10px; }
#header .svg-item li, #header .secondary-menu .svg-bg { background-size: 18px !important; background-position-x: 22px !important; padding-left: 28px; }
#header .svg-item li:hover, #header .secondary-menu .svg-bg:hover { background-color: #f4f4f4; }
#header .secondary-menu .svg-bg > a { background-color: transparent !important; }
#header .svg-item li > a { background: none !important; }
@media(max-width: 768px) { .logo-image { width: 140px !important; } }</style><div class="vc_row wpb_row row top-row header-main py-3 py-lg-0"><div class="vc_column_container flex-1 col-xl-2 col-4"><div class="wpb_wrapper vc_column-inner">
	<div class="wpb_single_image wpb_content_element vc_align_left   mb-0 pe-cxl-5 me-xl-space logo-image">
		<div class="wpb_wrapper">
			
			<a href="https://www.portotheme.com/" target="_self"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="180" height="44" src="https://www.portotheme.com/wp-content/uploads/porto_placeholders/100x24.jpg" data-oi="https://www.portotheme.com/wp-content/uploads/2023/01/footer-logo.png" class="porto-lazyload vc_single_image-img attachment-full" alt="Footer Logo" decoding="async" title="footer-logo" /></div></a>
		</div>
	</div>
<ul id="menu-main-menu-1" class="main-menu mega-menu show-arrow"><li id="nav-menu-item-487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home narrow"><a href="https://www.portotheme.com/">Home</a></li>
<li id="nav-menu-item-126" class="menu-item menu-item-type-post_type menu-item-object-page narrow"><a href="https://www.portotheme.com/our-products/">Our Themes</a></li>
<li id="nav-menu-item-214" class="menu-item menu-item-type-post_type menu-item-object-page narrow"><a href="https://www.portotheme.com/blog/">Blog</a></li>
<li id="nav-menu-item-566" class="menu-item menu-item-type-post_type_archive menu-item-object-forum narrow"><a href="https://www.portotheme.com/forums/">Forums</a></li>
<li class="menu-item"><a class="porto-link-login" href="https://www.portotheme.com/wp-login.php?redirect_to=https%3A%2F%2Fwww.portotheme.com">Log In</a></li></ul></div></div><div class="pt-2 vc_column_container flex-auto"><div class="wpb_wrapper vc_column-inner"><ul id="menu-secondary-menu" class="wpb_custom_db3c4b2877cf91e3ce78ef27fe9a6234 mr-4 secondary-menu main-menu mega-menu show-arrow"><li id="nav-menu-item-460" class="menu-item menu-item-type-custom menu-item-object-custom narrow"><a href="https://www.portotheme.com/support">Support</a></li>
<li id="nav-menu-item-461" class="menu-item menu-item-type-custom menu-item-object-custom narrow"><a href="https://www.portotheme.com/wordpress/porto/documentation">Documentation</a></li>
<li id="nav-menu-item-462" class="menu-item menu-item-type-custom menu-item-object-custom narrow"><a href="https://www.portotheme.com/customization/">Customization</a></li>
</ul><div class="vc_btn3-container  mb-0 btn-buy d-none d-md-block vc_btn3-inline vc_custom_1674324260361" >
	<a class="vc_btn3 vc_btn3-shape-rounded wpb_custom_6687b26f39488ddbb85ddb3c1ce8e111 btn btn-md btn-light" style="font-size:16px; font-weight:600; letter-spacing:-0.32px; padding:0.8125rem 1.9375rem;" href="https://www.portotheme.com/contact-us/" title="">Contact Us</a>	</div>
<a aria-label="Mobile Menu" href="#" class="mobile-toggle  wpb_custom_e325e190e075e76e8632d8c652b58be2"><i class="fas fa-bars"></i></a></div></div></div></div></div>
<div id="nav-panel">
	<div class="container">
		<div class="mobile-nav-wrap">
		<div class="menu-wrap"><ul id="menu-main-menu-2" class="mobile-menu accordion-menu"><li id="accordion-menu-item-487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home"><a href="https://www.portotheme.com/">Home</a></li>
<li id="accordion-menu-item-126" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.portotheme.com/our-products/">Our Themes</a></li>
<li id="accordion-menu-item-214" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://www.portotheme.com/blog/">Blog</a></li>
<li id="accordion-menu-item-566" class="menu-item menu-item-type-post_type_archive menu-item-object-forum"><a href="https://www.portotheme.com/forums/">Forums</a></li>
</ul><ul id="menu-secondary-menu-1" class="mobile-menu accordion-menu"><li id="accordion-menu-item-460" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.portotheme.com/support">Support</a></li>
<li id="accordion-menu-item-461" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.portotheme.com/wordpress/porto/documentation">Documentation</a></li>
<li id="accordion-menu-item-462" class="menu-item menu-item-type-custom menu-item-object-custom"><a href="https://www.portotheme.com/customization/">Customization</a></li>
<li class="menu-item"><a class="porto-link-login" href="https://www.portotheme.com/wp-login.php?redirect_to=https%3A%2F%2Fwww.portotheme.com">Log In</a></li></ul></div>		</div>
	</div>
</div>
</header>

									</div>
				<!-- end header wrapper -->
			
			
					<section class="page-top page-header-7">
		<div class="container">
	<div class="row">
		<div class="col-lg-12">
							<div class="breadcrumbs-wrap text-center">
					<ul class="breadcrumb" itemscope itemtype="https://schema.org/BreadcrumbList"><li class="home" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="https://www.portotheme.com" title="Go to Home Page"><span itemprop="name">Home</span></a><meta itemprop="position" content="1" /><i class="delimiter"></i></li><li>404</li></ul>				</div>
						<div class="text-center">
				<h1 class="page-title">404 - Page Not Found</h1>
							</div>
					</div>
	</div>
</div>
	</section>
	
		<div id="main" class="column1 boxed"><!-- main -->

			<div class="container">
			<div class="row main-content-wrap">

			<!-- main content -->
			<div class="main-content col-lg-12">

			
<div id="content" class="no-content">
	<div class="container">
		<section class="page-not-found">
			<div class="row">
				<div class="col-lg-6 offset-lg-1">
					<div class="page-not-found-main">
						<h2 class="entry-title">404 <i class="fas fa-file"></i></h2>
						<p>We're sorry, but the page you were looking for doesn't exist.</p>
					</div>
				</div>
									<div class="col-lg-4">
											</div>
							</div>
		</section>
	</div>
</div>

		

</div><!-- end main content -->



	</div>
	</div>

					
				
				</div><!-- end main -->

				
				<div class="footer-wrapper">

															<footer id="footer" class="footer footer-builder"><div class="porto-block" data-id="421"><style>.vc_custom_1676443002812{margin-top: 100px !important;}.vc_custom_1676311366113{border-top-width: 1px !important;border-top-color: #e7e7e7 !important;border-top-style: solid !important;}.vc_custom_1676311466685{margin-top: 39px !important;margin-bottom: 131px !important;}.wpb_custom_70092ef2d2aa963c9c3572dc4bf61c39 a{width: 42px;height: 42px;border-radius: 50%;}.wpb_custom_70092ef2d2aa963c9c3572dc4bf61c39.share-links a:not(:hover){color: #ffffff;background-color: #27292d;}.wpb_custom_70092ef2d2aa963c9c3572dc4bf61c39 a:hover{color: #ffffff;background-color: #0169fd;}.wpb_custom_c86c2fb53cae9eced42d4b8900a042f3{--porto-el-spacing: 0px;}.custom-align .owl-stage {
display: flex;
align-items: center;
}
.custom-align .wpb_single_image .vc_single_image-wrapper {
vertical-align: middle;
}
.sib-default-btn i::before {
    content: "\f061";
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
}
.custom-subscribe {
max-width: 289px;
}
input[type=email].sib-email-area {
    padding: 17px;
    background: #f3f3f3;
    border-radius: 4px;
    border-width: 0;
    max-width: 289px;
    width: 100%;
font-size: 13px;
    font-weight: 500;
}
input[type=email].sib-email-area::placeholder {
color: #777;
}
.sib-default-btn {
    border-radius: 4px;
    position: absolute;
    right: 5px;
    top: 5px;
    bottom: 5px;
    width: 45px;
    background: #0069ff;
}</style><div class="vc_row wpb_row top-row vc_custom_1676443002812 porto-inner-container"><div class="porto-wrap-container container"><div class="row"><div class="d-flex align-items-center mb-5 mb-xl-0 vc_column_container col-md-12 col-xl-3 col-lg-4"><div class="wpb_wrapper vc_column-inner">
	<div class="wpb_single_image wpb_content_element vc_align_left   mb-0 text-left text-xl-center">
		<div class="wpb_wrapper">
			
			<a href="https://www.portotheme.com/" target="_blank"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="180" height="44" src="https://www.portotheme.com/wp-content/uploads/porto_placeholders/100x24.jpg" data-oi="https://www.portotheme.com/wp-content/uploads/2023/01/Logo-1.png" class="porto-lazyload vc_single_image-img attachment-full" alt="Header Logo" decoding="async" title="Logo" /></div></a>
		</div>
	</div>
</div></div><div class="mb-5 mb-xl-0 vc_column_container col-md-6 col-xl-2 col-lg-4 col-12"><div class="wpb_wrapper vc_column-inner"><h3 style="font-size: 16px;color: #222529;line-height: 1;font-weight:700;letter-spacing:-.025em" class="vc_custom_heading align-left" >Our Products</h3><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/wordpress/porto_landing/" target="_blank" title="porto wordpress">Porto WordPress</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/magento/porto_landing/" target="_blank" title="porto magento">Porto Magento</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/shopify/porto/" target="_blank" title="porto shopify">Porto Shopify</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://alpustheme.com/alpus/" target="_blank" title="Riode WordPress">Alpus WordPress</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://d-themes.com/wordpress/riode/landing/" target="_blank" title="Riode WordPress">Riode WordPress</a></div></div></div><div class="mb-5 mb-xl-0 vc_column_container col-md-6 col-xl-2 col-lg-4 col-12"><div class="wpb_wrapper vc_column-inner"><h3 style="font-size: 16px;color: #222529;line-height: 1;font-weight:700;letter-spacing:-.025em" class="vc_custom_heading align-left" >Useful Links</h3><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/forums/" target="_blank" title="porto forum">Forum</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/support/" target="_blank" title="porto support">Support</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/wordpress/porto/documentation/" target="_blank" title="porto documentation">Docs</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/wordpress/porto_landing/demos_overview.html" target="_blank" title="porto demo overview">Prebuilt Websites</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/partners/" title="Porto Partner Page">Our Partners</a></div></div></div><div class="mb-5 mb-xl-0 vc_column_container col-md-6 col-xl-2 col-lg-4 col-12"><div class="wpb_wrapper vc_column-inner"><h3 style="font-size: 16px;color: #222529;line-height: 1;font-weight:700;letter-spacing:-.025em" class="vc_custom_heading align-left" >Company</h3><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/blog/" title="porto blog">Blog</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/contact-us/" title="porto contact us">Contact Us</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/privacy-policy/" target="_blank" title="porto privacy policy">Privacy Policy</a></div><div style="font-size: 14px;color: #777777;line-height: 40px;font-weight:500;letter-spacing:.005em" class="vc_custom_heading align-left" ><a href="https://www.portotheme.com/terms-and-conditions/" target="_blank" title="porto Terms and conditions">Terms and Conditions</a></div></div></div><div class="mb-5 mb-xl-0 vc_column_container col-md-6 col-xl-3 col-lg-4 col-12"><div class="wpb_wrapper vc_column-inner"><h3 style="font-size: 16px;color: #222529;line-height: 1;font-weight:700;letter-spacing:-.025em" class="vc_custom_heading align-left" >Subscribe To Newsletter:</h3>
	<div class="wpb_raw_code wpb_content_element wpb_raw_html" >
		<div class="wpb_wrapper">
						<form id="sib_signup_form_1" method="post" class="sib_signup_form">
				<div class="sib_loader" style="display:none;"><img
							src="https://www.portotheme.com/wp-includes/images/spinner.gif" alt="loader"></div>
				<input type="hidden" name="sib_form_action" value="subscribe_form_submit">
				<input type="hidden" name="sib_form_id" value="1">
                <input type="hidden" name="sib_form_alert_notice" value="Please fill out this field">
                <input type="hidden" name="sib_security" value="62eeaf19c8">
				<div class="sib_signup_box_inside_1">
					<div style="/*display:none*/" class="sib_msg_disp">
					</div>
                    					<div class="d-flex custom-subscribe sib-email-area position-relative">
    <input placeholder="Email Address" type="email" class="sib-email-area" name="email" required="required">
    <button type="submit" class="sib-default-btn"><i></i></button>
</div>
				</div>
			</form>
			<style>
				form#sib_signup_form_1 p.sib-alert-message {
    padding: 6px 12px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
form#sib_signup_form_1 p.sib-alert-message-error {
    background-color: #f2dede;
    border-color: #ebccd1;
    color: #a94442;
}
form#sib_signup_form_1 p.sib-alert-message-success {
    background-color: #dff0d8;
    border-color: #d6e9c6;
    color: #3c763d;
}
form#sib_signup_form_1 p.sib-alert-message-warning {
    background-color: #fcf8e3;
    border-color: #faebcc;
    color: #8a6d3b;
}
			</style>
			
		</div>
	</div>
<div class="share-links wpb_custom_70092ef2d2aa963c9c3572dc4bf61c39">		<a target="_blank"  rel="nofollow noopener noreferrer" class="share-facebook" href="https://www.facebook.com/" title="Facebook"></a>
				<a target="_blank"  rel="nofollow noopener noreferrer" class="share-twitter" href="https://www.twitter.com/swtheme/" title="Twitter"></a>
				<a target="_blank"  rel="nofollow noopener noreferrer" class="share-youtube" href="https://www.youtube.com/" title="Youtube"></a>
		</div></div></div></div></div></div><div class="vc_row wpb_row top-row porto-inner-container"><div class="porto-wrap-container container"><div class="row"><div class="d-none d-xl-block vc_column_container col-md-3"><div class="wpb_wrapper vc_column-inner"></div></div><div class="vc_column_container col-md-12 col-xl-9 col-lg-12 col-12"><div class="wpb_wrapper vc_column-inner"><div class="porto-carousel owl-carousel has-ccols ccols-xl-5 ccols-lg-4 ccols-md-3 ccols-sm-2 ccols-2 m-b-xl m-t-xxl pt-1 custom-align wpb_custom_c86c2fb53cae9eced42d4b8900a042f3" data-plugin-options="{&quot;stagePadding&quot;:0,&quot;margin&quot;:0,&quot;autoplay&quot;:false,&quot;mouseDrag&quot;:true,&quot;touchDrag&quot;:true,&quot;autoplayTimeout&quot;:5000,&quot;autoplayHoverPause&quot;:false,&quot;items&quot;:5,&quot;lg&quot;:4,&quot;md&quot;:3,&quot;sm&quot;:2,&quot;xs&quot;:2,&quot;nav&quot;:false,&quot;dots&quot;:false,&quot;animateIn&quot;:&quot;&quot;,&quot;animateOut&quot;:&quot;&quot;,&quot;loop&quot;:false,&quot;center&quot;:false,&quot;video&quot;:false,&quot;lazyLoad&quot;:false,&quot;fullscreen&quot;:false}">
	<div class="wpb_single_image wpb_content_element vc_align_center">
		<div class="wpb_wrapper">
			
			<a href="http://www.a2hosting.com/refer/98595" target="_blank"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="113" height="29" src="https://www.portotheme.com/wp-content/uploads/porto_placeholders/100x25.jpg" data-oi="https://www.portotheme.com/wp-content/uploads/2023/02/a2.png" class="porto-lazyload vc_single_image-img attachment-full" alt="a2hosting" decoding="async" title="a2" /></div></a>
		</div>
	</div>

	<div class="wpb_single_image wpb_content_element vc_align_center">
		<div class="wpb_wrapper">
			
			<a href="https://themeforest.net/" target="_blank"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="101" height="18" src="https://www.portotheme.com/wp-content/uploads/porto_placeholders/100x17.jpg" data-oi="https://www.portotheme.com/wp-content/uploads/2023/02/envato.png" class="porto-lazyload vc_single_image-img attachment-full" alt="Envato" decoding="async" title="envato" /></div></a>
		</div>
	</div>

	<div class="wpb_single_image wpb_content_element vc_align_center">
		<div class="wpb_wrapper">
			
			<a href="https://kinsta.com/" target="_blank"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="91" height="17" src="https://www.portotheme.com/wp-content/uploads/2023/02/kinsta.png" class="vc_single_image-img attachment-full" alt="kinsta - best hosting" decoding="async" title="kinsta" /></div></a>
		</div>
	</div>

	<div class="wpb_single_image wpb_content_element vc_align_center">
		<div class="wpb_wrapper">
			
			<a href="https://wpml.org/?aid=559357&amp;affiliate_key=ihRRdgT37hRK" target="_blank"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="90" height="34" src="https://www.portotheme.com/wp-content/uploads/2023/02/wpml.png" class="vc_single_image-img attachment-full" alt="WPML" decoding="async" title="wpml" /></div></a>
		</div>
	</div>

	<div class="wpb_single_image wpb_content_element vc_align_center">
		<div class="wpb_wrapper">
			
			<a href="https://woocommerce.com/" target="_blank"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="141" height="29" src="https://www.portotheme.com/wp-content/uploads/porto_placeholders/100x20.jpg" data-oi="https://www.portotheme.com/wp-content/uploads/2023/02/woo.png" class="porto-lazyload vc_single_image-img attachment-full" alt="woocommerce" decoding="async" title="woo" /></div></a>
		</div>
	</div>
</div></div></div><div class="vc_column_container col-md-12 vc_custom_1676311366113"><div class="wpb_wrapper vc_column-inner"><p style="font-size: 13px;color: #999999;line-height: 22px;text-align: center;font-weight:500;letter-spacing:-.025em" class="vc_custom_heading vc_custom_1676311466685" >© Copyright 2014 - 2023 | All rights reserved | Powered by P-THEMES</p></div></div></div></div></div></div></footer>
					
				</div>
							
					
	</div><!-- end wrapper -->
	
  <script>
  (function(){
  window['gobot'] = window['gobot'] || function(){(window['gobot'].queue = window['gobot'].queue || []).push(arguments)}
  var script = document.createElement('script')
  script.async = 1
  script.src = 'https://www.getgobot.com/app/v1/gobot-client.js'
  var insert = document.getElementsByTagName('script')[0]
  insert.parentNode.insertBefore(script, insert)
  })()
  gobot('create', '-NP8Vt1Lltzui1ieRy0P')
  gobot('pageview')
  </script>
  <script type="text/html" id="wpb-modifications"></script><script src='https://www.portotheme.com/wp-content/themes/porto-child/extend-purchase.js?ver=6.4.0' id='porto-bbp-extend-js'></script>
<script src='https://www.portotheme.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.7.2' id='swv-js'></script>
<script id='contact-form-7-js-extra'>
var wpcf7 = {"api":{"root":"https:\/\/www.portotheme.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
</script>
<script src='https://www.portotheme.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.7.2' id='contact-form-7-js'></script>
<script id='porto-live-search-js-extra'>
var porto_live_search = {"nonce":"f9a6881878"};
</script>
<script src='https://www.portotheme.com/wp-content/themes/porto/inc/lib/live-search/live-search.min.js?ver=6.7.2' id='porto-live-search-js'></script>
<script id='gdatt-attachments-js-extra'>
var gdbbPressAttachmentsInit = {"max_files":"4","are_you_sure":"This operation is not reversible. Are you sure?"};
</script>
<script src='https://www.portotheme.com/wp-content/plugins/gd-bbpress-attachments/js/front.min.js?ver=4.5_b2500_free' id='gdatt-attachments-js'></script>
<script src='https://www.portotheme.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.10.0' id='wpb_composer_front_js-js'></script>
<script src='https://www.portotheme.com/wp-content/themes/porto/js/bootstrap.optimized.min.js?ver=5.0.1' id='bootstrap-js'></script>
<script src='https://www.portotheme.com/wp-content/themes/porto/js/libs/jquery.cookie.min.js?ver=1.4.1' id='jquery-cookie-js'></script>
<script src='https://www.portotheme.com/wp-content/themes/porto/js/libs/owl.carousel.min.js?ver=2.3.4' id='owl.carousel-js'></script>
<script src='https://www.portotheme.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script async="async" src='https://www.portotheme.com/wp-content/themes/porto/js/libs/jquery.magnific-popup.min.js?ver=1.1.0' id='jquery-magnific-popup-js'></script>
<script id='porto-theme-js-extra'>
var js_porto_vars = {"rtl":"","theme_url":"https:\/\/www.portotheme.com\/wp-content\/themes\/porto-child","ajax_url":"https:\/\/www.portotheme.com\/wp-admin\/admin-ajax.php","change_logo":"1","container_width":"1240","grid_gutter_width":"20","show_sticky_header":"","show_sticky_header_tablet":"","show_sticky_header_mobile":"","ajax_loader_url":"\/\/www.portotheme.com\/wp-content\/themes\/porto\/images\/ajax-loader@2x.gif","category_ajax":"","compare_popup":"","compare_popup_title":"","prdctfltr_ajax":"","slider_loop":"1","slider_autoplay":"","slider_autoheight":"1","slider_speed":"5000","slider_nav":"","slider_nav_hover":"1","slider_margin":"","slider_dots":"1","slider_animatein":"","slider_animateout":"","product_thumbs_count":"4","product_zoom":"1","product_zoom_mobile":"1","product_image_popup":"1","zoom_type":"inner","zoom_scroll":"1","zoom_lens_size":"200","zoom_lens_shape":"square","zoom_contain_lens":"1","zoom_lens_border":"1","zoom_border_color":"#888888","zoom_border":"0","screen_lg":"1260","mfp_counter":"%curr% of %total%","mfp_img_error":"<a href=\"%url%\">The image<\/a> could not be loaded.","mfp_ajax_error":"<a href=\"%url%\">The content<\/a> could not be loaded.","popup_close":"Close","popup_prev":"Previous","popup_next":"Next","request_error":"The requested content cannot be loaded.<br\/>Please try again later.","loader_text":"Loading...","submenu_back":"Back","porto_nonce":"625ab41f87","use_skeleton_screen":[],"user_edit_pages":"","quick_access":"Click to edit this element.","goto_type":"Go To the Type Builder.","legacy_mode":"1"};
</script>
<script src='https://www.portotheme.com/wp-content/themes/porto/js/theme.min.js?ver=6.7.2' id='porto-theme-js'></script>
<script async="async" src='https://www.portotheme.com/wp-content/themes/porto/js/theme-async.min.js?ver=6.7.2' id='porto-theme-async-js'></script>
<script src='https://www.portotheme.com/wp-content/themes/porto/js/libs/lazyload.min.js?ver=1.9.7' id='lazyload-js'></script>
<script type="text/javascript">(function (undefined) {var _localizedStrings={"redirect_overlay_title":"Hold On","redirect_overlay_text":"You are being redirected to another page,<br>it may take a few seconds."};var _targetWindow="prefer-popup";var _redirectOverlay="overlay-with-spinner-and-message";
window.NSLPopup = function (url, title, w, h) {
    var userAgent = navigator.userAgent,
        mobile = function () {
            return /\b(iPhone|iP[ao]d)/.test(userAgent) ||
                /\b(iP[ao]d)/.test(userAgent) ||
                /Android/i.test(userAgent) ||
                /Mobile/i.test(userAgent);
        },
        screenX = window.screenX !== undefined ? window.screenX : window.screenLeft,
        screenY = window.screenY !== undefined ? window.screenY : window.screenTop,
        outerWidth = window.outerWidth !== undefined ? window.outerWidth : document.documentElement.clientWidth,
        outerHeight = window.outerHeight !== undefined ? window.outerHeight : document.documentElement.clientHeight - 22,
        targetWidth = mobile() ? null : w,
        targetHeight = mobile() ? null : h,
        V = screenX < 0 ? window.screen.width + screenX : screenX,
        left = parseInt(V + (outerWidth - targetWidth) / 2, 10),
        right = parseInt(screenY + (outerHeight - targetHeight) / 2.5, 10),
        features = [];
    if (targetWidth !== null) {
        features.push('width=' + targetWidth);
    }
    if (targetHeight !== null) {
        features.push('height=' + targetHeight);
    }
    features.push('left=' + left);
    features.push('top=' + right);
    features.push('scrollbars=1');

    var newWindow = window.open(url, title, features.join(','));

    if (window.focus) {
        newWindow.focus();
    }

    return newWindow;
};

var isWebView = null;

function checkWebView() {
    if (isWebView === null) {
        function _detectOS(ua) {
            if (/Android/.test(ua)) {
                return "Android";
            } else if (/iPhone|iPad|iPod/.test(ua)) {
                return "iOS";
            } else if (/Windows/.test(ua)) {
                return "Windows";
            } else if (/Mac OS X/.test(ua)) {
                return "Mac";
            } else if (/CrOS/.test(ua)) {
                return "Chrome OS";
            } else if (/Firefox/.test(ua)) {
                return "Firefox OS";
            }
            return "";
        }

        function _detectBrowser(ua) {
            var android = /Android/.test(ua);

            if (/Opera Mini/.test(ua) || / OPR/.test(ua) || / OPT/.test(ua)) {
                return "Opera";
            } else if (/CriOS/.test(ua)) {
                return "Chrome for iOS";
            } else if (/Edge/.test(ua)) {
                return "Edge";
            } else if (android && /Silk\//.test(ua)) {
                return "Silk";
            } else if (/Chrome/.test(ua)) {
                return "Chrome";
            } else if (/Firefox/.test(ua)) {
                return "Firefox";
            } else if (android) {
                return "AOSP";
            } else if (/MSIE|Trident/.test(ua)) {
                return "IE";
            } else if (/Safari\//.test(ua)) {
                return "Safari";
            } else if (/AppleWebKit/.test(ua)) {
                return "WebKit";
            }
            return "";
        }

        function _detectBrowserVersion(ua, browser) {
            if (browser === "Opera") {
                return /Opera Mini/.test(ua) ? _getVersion(ua, "Opera Mini/") :
                    / OPR/.test(ua) ? _getVersion(ua, " OPR/") :
                        _getVersion(ua, " OPT/");
            } else if (browser === "Chrome for iOS") {
                return _getVersion(ua, "CriOS/");
            } else if (browser === "Edge") {
                return _getVersion(ua, "Edge/");
            } else if (browser === "Chrome") {
                return _getVersion(ua, "Chrome/");
            } else if (browser === "Firefox") {
                return _getVersion(ua, "Firefox/");
            } else if (browser === "Silk") {
                return _getVersion(ua, "Silk/");
            } else if (browser === "AOSP") {
                return _getVersion(ua, "Version/");
            } else if (browser === "IE") {
                return /IEMobile/.test(ua) ? _getVersion(ua, "IEMobile/") :
                    /MSIE/.test(ua) ? _getVersion(ua, "MSIE ")
                        :
                        _getVersion(ua, "rv:");
            } else if (browser === "Safari") {
                return _getVersion(ua, "Version/");
            } else if (browser === "WebKit") {
                return _getVersion(ua, "WebKit/");
            }
            return "0.0.0";
        }

        function _getVersion(ua, token) {
            try {
                return _normalizeSemverString(ua.split(token)[1].trim().split(/[^\w\.]/)[0]);
            } catch (o_O) {
            }
            return "0.0.0";
        }

        function _normalizeSemverString(version) {
            var ary = version.split(/[\._]/);
            return (parseInt(ary[0], 10) || 0) + "." +
                (parseInt(ary[1], 10) || 0) + "." +
                (parseInt(ary[2], 10) || 0);
        }

        function _isWebView(ua, os, browser, version, options) {
            switch (os + browser) {
                case "iOSSafari":
                    return false;
                case "iOSWebKit":
                    return _isWebView_iOS(options);
                case "AndroidAOSP":
                    return false;
                case "AndroidChrome":
                    return parseFloat(version) >= 42 ? /; wv/.test(ua) : /\d{2}\.0\.0/.test(version) ? true : _isWebView_Android(options);
            }
            return false;
        }

        function _isWebView_iOS(options) {
            var document = (window["document"] || {});

            if ("WEB_VIEW" in options) {
                return options["WEB_VIEW"];
            }
            return !("fullscreenEnabled" in document || "webkitFullscreenEnabled" in document || false);
        }

        function _isWebView_Android(options) {
            if ("WEB_VIEW" in options) {
                return options["WEB_VIEW"];
            }
            return !("requestFileSystem" in window || "webkitRequestFileSystem" in window || false);
        }

        var options = {};
        var nav = window.navigator || {};
        var ua = nav.userAgent || "";
        var os = _detectOS(ua);
        var browser = _detectBrowser(ua);
        var browserVersion = _detectBrowserVersion(ua, browser);

        isWebView = _isWebView(ua, os, browser, browserVersion, options);
    }

    return isWebView;
}

function isAllowedWebViewForUserAgent(provider) {
    var facebookAllowedWebViews = [
        'Instagram',
        'FBAV',
        'FBAN'
    ], whitelist = [];

    if (provider && provider === 'facebook') {
        whitelist = facebookAllowedWebViews;
    }

    var nav = window.navigator || {};
    var ua = nav.userAgent || "";

    if (whitelist.length && ua.match(new RegExp(whitelist.join('|')))) {
        return true;
    }

    return false;
}

window._nslDOMReady(function () {

    window.nslRedirect = function (url) {
        if (_redirectOverlay) {
            var overlay = document.createElement('div');
            overlay.id = "nsl-redirect-overlay";
            var overlayHTML = '',
                overlayContainer = "<div id='nsl-redirect-overlay-container'>",
                overlayContainerClose = "</div>",
                overlaySpinner = "<div id='nsl-redirect-overlay-spinner'></div>",
                overlayTitle = "<p id='nsl-redirect-overlay-title'>" + _localizedStrings.redirect_overlay_title + "</p>",
                overlayText = "<p id='nsl-redirect-overlay-text'>" + _localizedStrings.redirect_overlay_text + "</p>";

            switch (_redirectOverlay) {
                case "overlay-only":
                    break;
                case "overlay-with-spinner":
                    overlayHTML = overlayContainer + overlaySpinner + overlayContainerClose;
                    break;
                default:
                    overlayHTML = overlayContainer + overlaySpinner + overlayTitle + overlayText + overlayContainerClose;
                    break;
            }

            overlay.insertAdjacentHTML("afterbegin", overlayHTML);
            document.body.appendChild(overlay);
        }

        window.location = url;
    };

    var targetWindow = _targetWindow || 'prefer-popup',
        lastPopup = false;


    var buttonLinks = document.querySelectorAll(' a[data-plugin="nsl"][data-action="connect"], a[data-plugin="nsl"][data-action="link"]');
    buttonLinks.forEach(function (buttonLink) {
        buttonLink.addEventListener('click', function (e) {
            if (lastPopup && !lastPopup.closed) {
                e.preventDefault();
                lastPopup.focus();
            } else {

                var href = this.href,
                    success = false;
                if (href.indexOf('?') !== -1) {
                    href += '&';
                } else {
                    href += '?';
                }

                var redirectTo = this.dataset.redirect;
                if (redirectTo === 'current') {
                    href += 'redirect=' + encodeURIComponent(window.location.href) + '&';
                } else if (redirectTo && redirectTo !== '') {
                    href += 'redirect=' + encodeURIComponent(redirectTo) + '&';
                }

                if (targetWindow !== 'prefer-same-window' && checkWebView()) {
                    targetWindow = 'prefer-same-window';
                }

                if (targetWindow === 'prefer-popup') {
                    lastPopup = NSLPopup(href + 'display=popup', 'nsl-social-connect', this.dataset.popupwidth, this.dataset.popupheight);
                    if (lastPopup) {
                        success = true;
                        e.preventDefault();
                    }
                } else if (targetWindow === 'prefer-new-tab') {
                    var newTab = window.open(href + 'display=popup', '_blank');
                    if (newTab) {
                        if (window.focus) {
                            newTab.focus();
                        }
                        success = true;
                        e.preventDefault();
                    }
                }

                if (!success) {
                    window.location = href;
                    e.preventDefault();
                }
            }
        });
    });

    let hasWebViewLimitation = false;

    var googleLoginButtons = document.querySelectorAll(' a[data-plugin="nsl"][data-provider="google"]');
    if (googleLoginButtons.length && checkWebView()) {
        googleLoginButtons.forEach(function (googleLoginButton) {
            googleLoginButton.remove();
            hasWebViewLimitation = true;
        });
    }

    var facebookLoginButtons = document.querySelectorAll(' a[data-plugin="nsl"][data-provider="facebook"]');
    if (facebookLoginButtons.length && checkWebView() && /Android/.test(window.navigator.userAgent) && !isAllowedWebViewForUserAgent('facebook')) {
        facebookLoginButtons.forEach(function (facebookLoginButton) {
            facebookLoginButton.remove();
            hasWebViewLimitation = true;
        });
    }


    const separators = document.querySelectorAll('div.nsl-separator');
    if (hasWebViewLimitation && separators.length) {
        separators.forEach(function (separator) {
            let separatorParentNode = separator.parentNode;
            if (separatorParentNode) {
                const separatorButtonContainer = separatorParentNode.querySelector('div.nsl-container-buttons');
                if (separatorButtonContainer && !separatorButtonContainer.hasChildNodes()) {
                    separator.remove();
                }
            }
        })
    }
});})();</script><script>if ( jQuery.cookie && 'off' === jQuery.cookie('porto_ads_status')) {
    jQuery('.porto-block-html-top > div').addClass('d-none');
} else {
    
}
jQuery('body').on('click', '.porto-block-html-top .mfp-close', function() {
   jQuery(this).parent().slideUp();
   //jQuery.cookie('porto_ads_status', 'off', { expires : 1 });
});</script></body>
</html>